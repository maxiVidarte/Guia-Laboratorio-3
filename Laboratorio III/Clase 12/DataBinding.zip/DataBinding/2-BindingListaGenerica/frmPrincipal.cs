﻿using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace _2_BindingListaGenerica
{


    public partial class FrmPrincipal : Form
    {
        private int _index;

        //Lista generics de Clientes
        private List<Clientes> _clientes;

        // Objeto BindingSource, para indicar cual sera el origen de datos
        private BindingSource _bs;

        // Objetos Binding, para enlazar los controles
        private Binding _boId;
        private Binding _boNombre;
        private Binding _boApellido;

        #region "Constructor"

        public FrmPrincipal()
        {
            InitializeComponent();
            AsignarManejadores();
            this._clientes = new List<Clientes>();

            this._bs = new BindingSource();

            // Cargo los clientes
            InicializarClientes();

            _bs.PositionChanged += CambioDeRegistro;
            _bs.DataError += BindingError;

            // Enlazo los controles
            Enlazar();

            // personalizo la grilla
            PersonalizarGrilla();

        }

        #endregion


        #region "Procedimientos"

        private void InicializarClientes()
        {
            // Los agrego a la lista
            this._clientes.Add(new Clientes(1, "Pepe", "Gomez"));
            this._clientes.Add(new Clientes(2, "Jorge", "Perez"));
            this._clientes.Add(new Clientes(3, "Juan", "Gonzalez"));
            this._clientes.Add(new Clientes(4, "Pedro", "Suarez"));
            this._clientes.Add(new Clientes(5, "Joaquin", "Morales"));

        }

        private void Enlazar()
        {

            // Creo un Objeto Binding y paso a que propiedad del control se va
            // a 'Bindear', le paso el BindingSource, no le doy formato y le 
            // indico cual va a ser la forma de tratar un cambio en los datos

            // NUNCA actualizar el ORIGEN DE DATOS
            this._boId = new Binding("Text", _bs, "Id", false, DataSourceUpdateMode.Never);
            txtId.DataBindings.Add(_boId);

            // ACTUALIZAR el ORIGEN DE DATOS cuando cambie el valor de la propiedad ASOCIADA
            this._boNombre = new Binding("Text", _bs, "Nombre", false, DataSourceUpdateMode.OnPropertyChanged);
            txtNombre.DataBindings.Add(_boNombre);

            // ACTUALIZAR el ORIGEN DE DATOS siempre y cuando se VALIDE la propiedad ASOCIADA
            this._boApellido = new Binding("Text", _bs, "Apellido", false, DataSourceUpdateMode.OnValidation);
            txtApellido.DataBindings.Add(_boApellido);

            // Le indico cual va a ser la fuente de datos
            this._bs.DataSource = _clientes;

        }

        private void PersonalizarGrilla()
        {

            // coloco color de fondo para las filas
            this.dgvGrilla.RowsDefaultCellStyle.BackColor = Color.Wheat;

            // Alterno colores 
            this.dgvGrilla.AlternatingRowsDefaultCellStyle.BackColor = Color.Lime;

            // Pongo color de fondo a la grilla
            this.dgvGrilla.BackgroundColor = Color.Beige;

            // Defino color de fondo y de fuente para el encabezado
            this.dgvGrilla.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
            this.dgvGrilla.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            this.dgvGrilla.ColumnHeadersDefaultCellStyle.Font = new Font(dgvGrilla.Font, FontStyle.Bold);
            this.dgvGrilla.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            // Defino el color de las lineas de separacion 
            this.dgvGrilla.GridColor = Color.HotPink;

            // La grilla sera de solo lectura
            this.dgvGrilla.ReadOnly = false;

            // No permito la multiseleccion
            this.dgvGrilla.MultiSelect = false;

            // Selecciono toda la fila a la vez
            this.dgvGrilla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            // Hago que las columnas ocupen todo el ancho del 'DataGrid'
            this.dgvGrilla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            // Indico el color de la fila selecciona
            dgvGrilla.RowsDefaultCellStyle.SelectionBackColor = Color.DarkOliveGreen;
            dgvGrilla.RowsDefaultCellStyle.SelectionForeColor = Color.WhiteSmoke;

            // No permito modificar desde la grilla
            this.dgvGrilla.EditMode = DataGridViewEditMode.EditProgrammatically;

            // Saco los encabezados de las filas 
            this.dgvGrilla.RowHeadersVisible = false;

        }

        private void InicializarForm(System.Object sender, System.EventArgs e)
        {

            // Coloco al BindingSource como 'DataSource' a la grilla
            dgvGrilla.DataSource = _bs;

        }


        private void AgregarCliente(System.Object sender, System.EventArgs e)
        {

            FrmClientes frm = new FrmClientes();
            frm.StartPosition = FormStartPosition.CenterParent;

            if (frm.ShowDialog() == DialogResult.OK)
            {
                // Agrego un nuevo cliente. 
                this._bs.Add(frm.Cliente);
            }

        }

        private void ContarClientes(System.Object sender, System.EventArgs e)
        {
            // Muestro cuantos clientes tengo
            MessageBox.Show(string.Format("Hay {0} Clientes", this._clientes.Count), "Cantidad de Clientes");

        }

        private void ConfirmarModificacion(System.Object sender, System.EventArgs e)
        {

            this._bs.RaiseListChangedEvents = false;

            this._boId.WriteValue();
            this._boNombre.WriteValue();
            this._boApellido.WriteValue();

            this._bs.RaiseListChangedEvents = true;

        }

        private void Eliminar(System.Object sender, System.EventArgs e)
        {

            // Elimino al registro actualmente seleccionado
            this._bs. RemoveCurrent();
        }

        #endregion

        #region "Eventos"

        private void CambioDeRegistro(System.Object sender, System.EventArgs e)
        {
        }

        private void BindingError(System.Object sender, BindingManagerDataErrorEventArgs e)
        {
            MessageBox.Show(e.Exception.Message);
        }



        private void txtApellido_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {

            // SI EL DATO NO ES VALIDO, CANCELO LA VALIDACION
            if (string.IsNullOrEmpty(this.txtApellido.Text))
            {
                e.Cancel = true;

                // SETEO AL OBJETO ERRORPROVIDER
                errorProvider1.SetError(txtApellido, "El APELLIDO no puede estar VACIO!!!");
                errorProvider1.BlinkRate = 500;
                errorProvider1.BlinkStyle = ErrorBlinkStyle.AlwaysBlink;

                // Cancelo la edición
                this._bs.CancelEdit();

                // Guardo el indice
                _index = this.dgvGrilla.SelectedRows[0].Index;

            }

        }

        private void txtApellido_Validated(System.Object sender, System.EventArgs e)
        {
            // ES VALIDO EL CAMPO, LIMPIO EL ERRORPROVIDER 
            errorProvider1.Clear();
        }



        private void dgvGrilla_SelectionChanged(System.Object sender, System.EventArgs e)
        {

            // Si existe un ERROR, posiciono al BINDINGSOURCE en el lugar del error
            if (errorProvider1.GetError(this.txtApellido) != "")
                this._bs.Position = _index;


        }

        #endregion

        private void AsignarManejadores()
        {
            btnAgregar.Click += AgregarCliente;
            btnConfirmar.Click += ConfirmarModificacion;
            btnCuantos.Click += ContarClientes;
            btnEliminar.Click += Eliminar;
            this.Load += InicializarForm;
            txtApellido.Validating += txtApellido_Validating;
            txtApellido.Validated += txtApellido_Validated;
        }
    }
}
