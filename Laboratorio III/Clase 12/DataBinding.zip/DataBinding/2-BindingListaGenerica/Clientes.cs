﻿namespace _2_BindingListaGenerica
{
    public class Clientes
    {

        private string _apellido ;
        private string  _nombre ;
        private int _id ;


        public Clientes(int id, string apellido, string nombre)
        {
            this._id = id;
            this._apellido = apellido;
            this._nombre = nombre;
        }

        #region "Propiedades"

        public int Id
        {
            get { return _id; }
            set { _id= value; }
        }

        
        public string Nombre
        {
            get { return _nombre; }
            set { _nombre = value; }
        }

        public string Apellido
        {
            get { return _apellido; }
            set { _apellido = value; }
        }

        #endregion

    }
}
