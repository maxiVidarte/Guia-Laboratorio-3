﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _2_BindingListaGenerica
{
    public partial class FrmClientes : Form
    {
        private Clientes _cliente;

        public FrmClientes()
        {
            InitializeComponent();
        }

        public Clientes Cliente
        {
            get { return _cliente; }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            this._cliente = new Clientes(int.Parse(this.txtId.Text), this.txtNombre.Text, this.txtApellido.Text);
            this.DialogResult = DialogResult.OK;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }



    }
}
