﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _01_IntroDataBinding
{
    class Persona
    {

        private string _apellido ;

        private string  _nombre ;

        private int _edad ;

        private long _dni ;


        public Persona(long dni)
        {
            this._dni = dni;
        }

        #region "Propiedades"

        public long Dni
        {
            get { return _dni; }
            set { _dni = value; }
        }


        public int Edad
        {
            get { return _edad; }
            set { _edad = value; }
        }

        
        public string Nombre
        {
            get { return _nombre; }
            set { _nombre = value; }
        }

        public string Apellido
        {
            get { return _apellido; }
            set { _apellido = value; }
        }

        #endregion

    }
}
