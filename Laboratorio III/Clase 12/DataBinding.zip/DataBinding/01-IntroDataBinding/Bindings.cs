﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _01_IntroDataBinding
{
    public partial class Bindings : Form
    {

        private BindingSource _bs;
        private DataSet _ds;

        #region "Constructor"

        public Bindings()
        {
            InitializeComponent();

            // llamo a la funcion TraerDataSet
            this._ds = Datos.TraerDataSet();

            // Acepto los cambios
            this._ds.AcceptChanges();

            // Configuro el BindingSource
            this._bs = new BindingSource();
            this._bs.DataSource = _ds;
            this._bs.DataMember = "Persona";

            // O de otra forma
            //_bs = new BindingSource(_ds, "Persona");

            // Inicializo la grilla
            InicializarGrilla();

        }

        #endregion

        #region Load

        private void Bindings_Load(object sender, EventArgs e)
        {
            // Enlazo los controles

            // La Grilla al BindingSource
            this.dgvGrilla.DataSource = _bs;

            // El txtDni
            // Enlazo la propiedad 'Text' con la columna 'Dni'
            this.txtDni.DataBindings.Add("Text", _bs, "Dni");

            // El txtApellido
            // Enlazo la propiedad 'Text' con la columna 'Apellido'
            Binding boApellido = new Binding("Text", _bs, "Apellido");
            this.txtApellido.DataBindings.Add(boApellido);

            // El txtNombre
            // Enlazo la propiedad 'Text' con la columna 'Nombre'
            this.txtNombre.DataBindings.Add(new Binding("Text", _bs, "Nombre"));

            // El txtEdad
            // Enlazo la propiedad 'Text' con la columna 'Edad'
            this.txtEdad.DataBindings.Add("Text", _bs, "Edad");
        }

        #endregion

        #region "Métodos"

        private void InicializarGrilla()
        {

            dgvGrilla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvGrilla.EnableHeadersVisualStyles = true;

            // seteo el formato del encabezado
            this.dgvGrilla.RowHeadersDefaultCellStyle.BackColor = Color.BlueViolet;
            this.dgvGrilla.RowHeadersDefaultCellStyle.ForeColor = Color.HotPink;
            dgvGrilla.RowHeadersVisible = false;
            dgvGrilla.ColumnHeadersVisible = true;


            // doy formato a las filas
            this.dgvGrilla.RowsDefaultCellStyle.BackColor = Color.MediumPurple;
            this.dgvGrilla.RowsDefaultCellStyle.ForeColor = Color.Gold;


            this.dgvGrilla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvGrilla.EditMode = DataGridViewEditMode.EditProgrammatically;

            this.dgvGrilla.AllowUserToAddRows = false;
            this.dgvGrilla.AllowUserToDeleteRows = false;
            this.dgvGrilla.AllowUserToResizeColumns = false;
            this.dgvGrilla.AllowUserToResizeRows = false;
            this.dgvGrilla.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            this.dgvGrilla.BackgroundColor = Color.Aqua;
            this.dgvGrilla.BorderStyle = BorderStyle.Fixed3D;
            this.dgvGrilla.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            this.dgvGrilla.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            this.dgvGrilla.ColumnHeadersDefaultCellStyle.BackColor = Color.Aqua;
            this.dgvGrilla.DefaultCellStyle.BackColor = Color.Black;
            this.dgvGrilla.EnableHeadersVisualStyles = true;



            dgvGrilla.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
            dgvGrilla.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvGrilla.GridColor = Color.Red;

        }

        private void btnVerRowState_Click(System.Object sender, System.EventArgs eventArgs)
        {
            StringBuilder sb = new StringBuilder();

            foreach (DataRow fila in  this._ds.Tables[0].Rows)
            {
                sb.AppendLine(fila.RowState.ToString());
            }


            MessageBox.Show(sb.ToString(), "Estado de las filas", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        #endregion



        #region "Movimientos"

        private void Primero_Click(object sender, EventArgs e)
        {
            _bs.MoveFirst();
        }

        private void Anterior_Click(object sender, EventArgs e)
        {
            _bs.MovePrevious();
        }

        private void Siguiente_Click(object sender, EventArgs e)
        {
            _bs.MoveNext();
        }

        private void Ultimo_Click(object sender, EventArgs e)
        {
            _bs.MoveLast();
        }

        #endregion

    }
}