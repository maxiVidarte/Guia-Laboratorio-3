﻿namespace _01_IntroDataBinding
{
    partial class Bindings
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvGrilla = new System.Windows.Forms.DataGridView();
            this.Primero = new System.Windows.Forms.Button();
            this.btnVerRowState = new System.Windows.Forms.Button();
            this.txtEdad = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Ultimo = new System.Windows.Forms.Button();
            this.Siguiente = new System.Windows.Forms.Button();
            this.Anterior = new System.Windows.Forms.Button();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.txtDni = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGrilla)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGrilla
            // 
            this.dgvGrilla.Location = new System.Drawing.Point(13, 13);
            this.dgvGrilla.Name = "dgvGrilla";
            this.dgvGrilla.Size = new System.Drawing.Size(431, 176);
            this.dgvGrilla.TabIndex = 0;
            // 
            // Primero
            // 
            this.Primero.Location = new System.Drawing.Point(300, 200);
            this.Primero.Name = "Primero";
            this.Primero.Size = new System.Drawing.Size(30, 23);
            this.Primero.TabIndex = 19;
            this.Primero.Text = "<<";
            this.Primero.UseVisualStyleBackColor = true;
            this.Primero.Click += new System.EventHandler(this.Primero_Click);
            // 
            // btnVerRowState
            // 
            this.btnVerRowState.Location = new System.Drawing.Point(300, 252);
            this.btnVerRowState.Name = "btnVerRowState";
            this.btnVerRowState.Size = new System.Drawing.Size(138, 23);
            this.btnVerRowState.TabIndex = 36;
            this.btnVerRowState.Text = "Ver RowState";
            this.btnVerRowState.UseVisualStyleBackColor = true;
            this.btnVerRowState.Click += new System.EventHandler(this.btnVerRowState_Click);
            // 
            // txtEdad
            // 
            this.txtEdad.Location = new System.Drawing.Point(69, 275);
            this.txtEdad.Name = "txtEdad";
            this.txtEdad.Size = new System.Drawing.Size(100, 20);
            this.txtEdad.TabIndex = 35;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(12, 278);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(32, 13);
            this.Label4.TabIndex = 34;
            this.Label4.Text = "Edad";
            // 
            // Ultimo
            // 
            this.Ultimo.Location = new System.Drawing.Point(408, 200);
            this.Ultimo.Name = "Ultimo";
            this.Ultimo.Size = new System.Drawing.Size(30, 23);
            this.Ultimo.TabIndex = 33;
            this.Ultimo.Text = ">>";
            this.Ultimo.UseVisualStyleBackColor = true;
            this.Ultimo.Click += new System.EventHandler(this.Ultimo_Click);
            // 
            // Siguiente
            // 
            this.Siguiente.Location = new System.Drawing.Point(372, 200);
            this.Siguiente.Name = "Siguiente";
            this.Siguiente.Size = new System.Drawing.Size(30, 23);
            this.Siguiente.TabIndex = 32;
            this.Siguiente.Text = ">";
            this.Siguiente.UseVisualStyleBackColor = true;
            this.Siguiente.Click += new System.EventHandler(this.Siguiente_Click);
            // 
            // Anterior
            // 
            this.Anterior.Location = new System.Drawing.Point(336, 200);
            this.Anterior.Name = "Anterior";
            this.Anterior.Size = new System.Drawing.Size(30, 23);
            this.Anterior.TabIndex = 31;
            this.Anterior.Text = "<";
            this.Anterior.UseVisualStyleBackColor = true;
            this.Anterior.Click += new System.EventHandler(this.Anterior_Click);
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(69, 249);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(100, 20);
            this.txtNombre.TabIndex = 30;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(12, 226);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(44, 13);
            this.Label3.TabIndex = 29;
            this.Label3.Text = "Apellido";
            // 
            // txtApellido
            // 
            this.txtApellido.Location = new System.Drawing.Point(69, 223);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(100, 20);
            this.txtApellido.TabIndex = 28;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(12, 252);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(44, 13);
            this.Label2.TabIndex = 27;
            this.Label2.Text = "Nombre";
            // 
            // txtDni
            // 
            this.txtDni.Location = new System.Drawing.Point(69, 197);
            this.txtDni.Name = "txtDni";
            this.txtDni.Size = new System.Drawing.Size(100, 20);
            this.txtDni.TabIndex = 26;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(12, 200);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(23, 13);
            this.Label1.TabIndex = 25;
            this.Label1.Text = "Dni";
            // 
            // Bindings
            // 
            this.ClientSize = new System.Drawing.Size(472, 325);
            this.Controls.Add(this.btnVerRowState);
            this.Controls.Add(this.txtEdad);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Ultimo);
            this.Controls.Add(this.Siguiente);
            this.Controls.Add(this.Anterior);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.txtApellido);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.txtDni);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Primero);
            this.Controls.Add(this.dgvGrilla);
            this.Name = "Bindings";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Bindings_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGrilla)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGrilla;
        internal System.Windows.Forms.Button Primero;
        internal System.Windows.Forms.Button btnVerRowState;
        internal System.Windows.Forms.TextBox txtEdad;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Button Ultimo;
        internal System.Windows.Forms.Button Siguiente;
        internal System.Windows.Forms.Button Anterior;
        internal System.Windows.Forms.TextBox txtNombre;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox txtApellido;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox txtDni;
        internal System.Windows.Forms.Label Label1;
    }
}

