﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace _01_IntroDataBinding
{
    class Datos
    {
        public static DataSet TraerDataSet(){

        // Creo un DataSet
        DataSet ds = new DataSet();

        // Agrego el nombre de la tabla
            ds.Tables.Add("Persona");

        // Agrego nombre y tipo de Dato
            ds.Tables["Persona"].Columns.Add("Dni", typeof(Int64));
            ds.Tables["Persona"].Columns.Add("Apellido", typeof(string));
            ds.Tables["Persona"].Columns.Add("Nombre", typeof(string));
            ds.Tables["Persona"].Columns.Add("Edad", typeof(Int32));


            DataRow filaNueva = ds.Tables["Persona"].NewRow();

            filaNueva["Dni"] = 66555444;
            filaNueva[1] = "Fernandez";
            filaNueva["Nombre"] = "Juana";
            filaNueva[3] = 25;

            
        // Agrego Filas
            ds.Tables[0].Rows.Add(new Object[] {25333666,"Perez", "Jose",33});
            ds.Tables[0].Rows.Add(new Object[] {30999888, "Gomez", "Jorge", 23});
            ds.Tables[0].Rows.Add(new Object[] {21999444, "Sanchez", "Antonio", 62});
            ds.Tables[0].Rows.Add(new Object[] {37000111, "Martinez", "Maria", 18});
            ds.Tables[0].Rows.Add(new Object[] {99555333, "Roberts", "Julia", 55});
            ds.Tables[0].Rows.Add(filaNueva);
        

        // Devuelvo el dataset
            return ds;

        }
    }
}
