﻿namespace _3_BindingBaseDatos
{
    public class Persona
    {

        private string _apellido ;

        private string  _nombre ;

        private int _edad ;

        private long _dni ;


        public Persona(long dni)
        {
            this._dni = dni;
        }

        public Persona(long dni, string nombre, string apellido, int edad)
        {
            this._dni = dni;
            this._nombre = nombre;
            this._apellido = apellido;
            this._edad = edad;
        }

        #region "Propiedades"

        public long Dni
        {
            get { return _dni; }
            set { _dni = value; }
        }


        public int Edad
        {
            get { return _edad; }
            set { _edad = value; }
        }

        
        public string Nombre
        {
            get { return _nombre; }
            set { _nombre = value; }
        }

        public string Apellido
        {
            get { return _apellido; }
            set { _apellido = value; }
        }

        #endregion

    }
}
