﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _3_BindingBaseDatos
{
    public partial class FrmPrincipal : Form
    {
            // Declaro los objetos: DataSet y el BindingSource
        private DataSet _ds;
        private BindingSource _bsClientes;

    // Declaro un objeto de tipo Binding por cada control a 'enlazar'
        private Binding _boDni ;
        private Binding _boNombre ;
        private Binding _boApellido ;
        private Binding _boEdad;
        private Binding _boNroCuenta;
        private Binding _boSaldo;
        private Binding _boEstado;

        public FrmPrincipal()
        {
            InitializeComponent();

            this._bsClientes = new BindingSource();
            this._ds = new DataSet();

            // Inicializo mi lista de clientes
            InicializarClientes();

            // Enlazo las propiedades de los controles
            Enlazar();

            // Inicializo la grilla
            InicializarGrilla();


        }

        #region Procedimientos

        private void InicializarClientes()
        {
            this.Load += InicializarFormulario;
            cmdAgregar.Click += AgregarClientes;
            cmdCantidad.Click += Eliminar;
            cmdConfirmar.Click += Confirmar;
            cmdEditar.Click += Editar_Click;

            try
            {
                _ds.Clear();
            }
            catch (NullReferenceException ex)
            {
            }
            finally
            {
                // Traigo los datos desde la Base de Datos
                _ds = Clientes.TraerDatos();
            }


        }

        private void Enlazar()
        {

            _boDni = new Binding("Text", _bsClientes, "Dni", false, DataSourceUpdateMode.Never);
            txtDni.DataBindings.Add(_boDni);

            _boNombre = new Binding("Text", _bsClientes, "Nombre", false, DataSourceUpdateMode.Never);
            txtNombre.DataBindings.Add(_boNombre);

            _boApellido = new Binding("Text", _bsClientes, "Apellido", false, DataSourceUpdateMode.Never);
            txtApellido.DataBindings.Add(_boApellido);

            _boEdad = new Binding("Text", _bsClientes, "Edad", false, DataSourceUpdateMode.Never);
            txtEdad.DataBindings.Add(_boEdad);

            _boNroCuenta = new Binding("Text", _bsClientes, "NroCuenta", false, DataSourceUpdateMode.Never);
            txtCuenta.DataBindings.Add(_boNroCuenta);

            _boSaldo = new Binding("Text", _bsClientes, "Saldo", false, DataSourceUpdateMode.Never);
            txtSaldo.DataBindings.Add(_boSaldo);

            _bsClientes.DataSource = _ds.Tables["Clientes"];

        }

        private void InicializarFormulario(object sender, System.EventArgs e)
        {
            // Indico cual sera la fuente de datos de la grilla
            dgvGrilla.DataSource = _bsClientes;
        }

        private void AgregarClientes(object sender, System.EventArgs e)
        {
            FormDatos frm = new FormDatos();

            frm.Text = "Agregar Nuevo Cliente";
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.DniEnabled = true;
            frm.SaldoVisible = false;

            frm.ShowDialog();

            // Si 'Acepto' agrego al DataSet
            if (frm.DialogResult == DialogResult.OK)
            {

                // Creo un cliente y lo cargo con el contenido del form
                Clientes cliente = new Clientes(frm.Dni, frm.Nombre, frm.Apellido, frm.Edad, frm.Cuenta);

                // Agrego al Cliente al DataTable
                _ds.Tables["Clientes"].Rows.Add(new Object[]
                {
                    cliente.NroCuenta,
                    cliente.Dni,
                    cliente.Nombre,
                    cliente.Apellido,
                    cliente.Edad,
                    cliente.Saldo
                });
                
                // Actualizo la Base
                cliente.AgregarCliente();

                // Me posiciono al principio
                _bsClientes.MoveFirst();

            }


        }
        

        private void Eliminar(Object sender, System.EventArgs e)
        {

            if (MessageBox.Show("Esta seguro de eliminar al cliente?", "Borrar",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                _bsClientes.RemoveCurrent();
                Clientes.EliminarCliente();

            }

        }
        

        private void Confirmar(Object sender, EventArgs e)
        {

            _bsClientes.RaiseListChangedEvents = false;

            _boDni.WriteValue();
            _boNombre.WriteValue();
            _boApellido.WriteValue();
            _boEdad.WriteValue();
            // No debo modificar NroCuenta, ya que es PK
            //_boNroCuenta.WriteValue();
            _boSaldo.WriteValue();

            _bsClientes.RaiseListChangedEvents = true;

            dgvGrilla.SelectedRows[0].Selected = true;

            // Modifico los datos
            Modifico();

        }


        private void Editar_Click(Object sender, EventArgs e)
        {
            MessageBox.Show("Propiedad AllowEdit = " + _bsClientes.AllowEdit.ToString());
        }

        private void InicializarGrilla()
        {

            dgvGrilla.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvGrilla.ColumnHeadersDefaultCellStyle.BackColor = Color.Black;
            dgvGrilla.EnableHeadersVisualStyles = true;
            // seteo el formato del encabezado
            dgvGrilla.RowHeadersDefaultCellStyle.BackColor = Color.AliceBlue;
            dgvGrilla.RowHeadersVisible = false;
            dgvGrilla.ColumnHeadersVisible = true;

            // doy formato a las filas
            this.dgvGrilla.RowsDefaultCellStyle.BackColor = Color.MediumPurple;
            this.dgvGrilla.RowsDefaultCellStyle.ForeColor = Color.Gold;

            dgvGrilla.MultiSelect = false;

            this.dgvGrilla.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvGrilla.AllowUserToAddRows = false;
            this.dgvGrilla.AllowUserToDeleteRows = false;
            this.dgvGrilla.AllowUserToResizeColumns = false;
            this.dgvGrilla.AllowUserToResizeRows = false;
            this.dgvGrilla.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            this.dgvGrilla.BackgroundColor = Color.Aqua;
            this.dgvGrilla.BorderStyle = BorderStyle.Fixed3D;
            this.dgvGrilla.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
            this.dgvGrilla.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            this.dgvGrilla.ColumnHeadersDefaultCellStyle.BackColor = Color.Aqua;
            this.dgvGrilla.DefaultCellStyle.BackColor = Color.Black;
            this.dgvGrilla.EnableHeadersVisualStyles = true;
            this.dgvGrilla.EditMode = DataGridViewEditMode.EditProgrammatically;

            this.dgvGrilla.RowHeadersDefaultCellStyle.BackColor = Color.BlueViolet;
            this.dgvGrilla.RowHeadersDefaultCellStyle.ForeColor = Color.HotPink;

        }

        #endregion

        
#region Eventos

        private void Modifico()
        {

            //Posiciono al principio 
            _bsClientes.MoveFirst();

            Clientes.ModificarCliente();
        }



        #endregion
    }
}
