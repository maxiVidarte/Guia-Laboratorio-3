﻿using System;
using System.Windows.Forms;

namespace _3_BindingBaseDatos
{
    public partial class FormDatos : Form
    {

        #region Propiedades

        public long Dni
        {
            get { return Int64.Parse(txtDni.Text); }
            set { txtDni.Text = value.ToString(); }
        }

        public string Apellido
        {
            get { return txtApellido.Text; }
            set { txtApellido.Text = value; }
        }

        public string Nombre
        {
            get { return txtNombre.Text; }
            set { txtNombre.Text = value; }
        }

        public int Edad
        {
            get { return Int32.Parse(txtEdad.Text); }
            set { txtEdad.Text = value.ToString(); }
        }

        public int Cuenta
        {
            get { return Int32.Parse(txtNroCuenta.Text); }
            set { txtNroCuenta.Text = value.ToString(); }
        }

        public double Saldo
        {
            get { return double.Parse(txtSaldo.Text); }
            set { txtSaldo.Text = value.ToString(); }
        }


        public bool DniEnabled
        {
            get { return txtDni.Enabled; }
            set { txtDni.Enabled = value; }
        }

        public bool SaldoVisible
        {
            get { return txtSaldo.Visible; }
            set { txtSaldo.Visible = value; }
        }

        #endregion

        private void cmdAceptar_Click(Object sender, EventArgs e)
        {
            // Retorno "OK"
            this.DialogResult = DialogResult.OK;
        }

        private void cmdCancelar_Click(Object sender, EventArgs e)
        {
            // Retorno "CANCEL"
            this.DialogResult = DialogResult.Cancel;
        }

        public FormDatos()
        {
            InitializeComponent();
            cmdCancelar.Click += cmdCancelar_Click;
            cmdAceptar.Click += cmdAceptar_Click;
        }
    }
}