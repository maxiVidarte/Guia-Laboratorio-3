﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;

namespace _3_BindingBaseDatos
{
    public class Clientes : Persona
    {

        private int _nroCuenta;
        private double _saldo;

        #region Objetos ADO Net

        // Declaro los objetos de ADO NET

        // Declaro el DataSet
        private static DataSet _ds = new DataSet();

        //Para Sql

        private static SqlDataAdapter _daCliente;


        private static SqlCommand _cmdSelectCliente;
        private static SqlCommand _cmdInsertCliente;
        private static SqlCommand _cmdUpdateCliente;
        private static SqlCommand _cmdDeleteCliente;

        private static SqlConnection _cn;

        // Para OleDb

        //private static  OleDbDataAdapter _daOle;

        //private static OleDbCommand _cmdSelectOle ;
        //private static OleDbCommand _cmdInsertOle ;
        //private static OleDbCommand _cmdUpdateOle ;
        //private static OleDbCommand _cmdDeleteOle ;

        //private static OleDbConnection _cnOle ;

        #endregion

        #region Configuracion del DataAdapter

        private static void ConfigurarDataAdapter()
        {
            
            string cadena;

            // Para Sql

            // Instancio una nueva conexion
            cadena = ConfigurationManager.ConnectionStrings["ClientesConn"].ToString();
                
            _cn = new SqlConnection(cadena);


            cadena = "SELECT * FROM CLIENTES";

            // Configuro los comandos de: Seleccion, Insercion, Modificacion y Eliminacion
            _cmdSelectCliente = new SqlCommand(cadena, _cn);

            _cmdInsertCliente = new SqlCommand("INSERT INTO CLIENTES (NroCuenta, Dni, Apellido, " +
                                               "Nombre, Edad, Saldo) VALUES (@nroCuenta, @dni, @apellido, " +
                                               "@nombre, @edad, @saldo)", _cn);

            _cmdUpdateCliente = new SqlCommand("UPDATE CLIENTES SET Dni = @dni, Apellido = @apellido, " +
                                               "Nombre = @nombre, Edad = @edad, Saldo = @saldo " +
                                               "WHERE NroCuenta = @nroCuenta", _cn);

            _cmdDeleteCliente = new SqlCommand("DELETE FROM CLIENTES WHERE NroCuenta = @nroCuenta", _cn);


            // Instancio el Data Adapter
            _daCliente = new SqlDataAdapter();

            // Paso el comando de seleccion al 'SelectCommand'
            _daCliente.SelectCommand = _cmdSelectCliente;

            // Paso el comando de insercion al 'SelectInsert'
            _daCliente.InsertCommand = _cmdInsertCliente;

            // creo los parametros que va a utilizar
            _daCliente.InsertCommand.Parameters.Add("@nroCuenta", SqlDbType.Int, 0, "NroCuenta");
            _daCliente.InsertCommand.Parameters.Add("@dni", SqlDbType.BigInt, 0, "Dni");
            _daCliente.InsertCommand.Parameters.Add("@apellido", SqlDbType.VarChar, 50, "Apellido");
            _daCliente.InsertCommand.Parameters.Add("@nombre", SqlDbType.VarChar, 50, "Nombre");
            _daCliente.InsertCommand.Parameters.Add("@edad", SqlDbType.Int, 0, "Edad");
            _daCliente.InsertCommand.Parameters.Add("@saldo", SqlDbType.Float, 50, "Saldo");

            // Paso el comando de modificacion al 'UpDateCommand'
            _daCliente.UpdateCommand = _cmdUpdateCliente;

            // Creo los parametros que va a utilizar
            _daCliente.UpdateCommand.Parameters.Add("@nroCuenta", SqlDbType.Int, 0, "NroCuenta");
            _daCliente.UpdateCommand.Parameters.Add("@dni", SqlDbType.BigInt, 0, "Dni");
            _daCliente.UpdateCommand.Parameters.Add("@apellido", SqlDbType.VarChar, 50, "Apellido");
            _daCliente.UpdateCommand.Parameters.Add("@nombre", SqlDbType.VarChar, 50, "Nombre");
            _daCliente.UpdateCommand.Parameters.Add("@edad", SqlDbType.Int, 0, "Edad");
            _daCliente.UpdateCommand.Parameters.Add("@saldo", SqlDbType.Float, 50, "Saldo");

            // Paso el comando de eliminacion al 'DeleteCommand'
            _daCliente.DeleteCommand = _cmdDeleteCliente;

            // creo los parametros que va a utilizar
            _daCliente.DeleteCommand.Parameters.Add("@nroCuenta", SqlDbType.Int, 0, "NroCuenta");


            // Para OleDb

            //// Instancio una nueva conexion
            //_cnOle = new OleDbConnection(Settings.PersonasConn);

            // string cadena  = "Select Dni, Nombre, Apellido, Edad from Personas";

            //// Defino los Comandos de: Seleccion, Insercion, Modificacion y Eliminacion
            //_cmdSelectOle = new OleDbCommand(cadena, _cnOle);
            //_cmdInsertOle =new OleDbCommand("INSERT INTO PERSONAS (Dni, Apellido, Nombre, Edad) VALUES (@dni, @apellido, @nombre, @edad)", _cnOle);
            //_cmdUpdateOle = new OleDbCommand("UPDATE PERSONAS SET Apellido = @apellido, Nombre = @nombre, Edad = @edad WHERE Dni = @dni", _cnOle);
            //_cmdDeleteOle = new OleDbCommand("DELETE FROM PERSONAS WHERE Dni = @dni", _cnOle);

            //// Instancio el Data Adapter
            //_daOle = new OleDbDataAdapter();

            //// Paso el comando de seleccion al 'SelectCommand'
            //_daOle.SelectCommand = _cmdSelectOle;

            //// Paso el comando de insercion al 'SelectInsert'
            //_daOle.InsertCommand = _cmdInsertOle;

            //// creo los parametros que va a utilizar
            //_daOle.InsertCommand.Parameters.Add("@dni", OleDbType.BigInt, 0, "Dni");
            //_daOle.InsertCommand.Parameters.Add("@apellido", OleDbType.VarChar, 50, "Apellido");
            //_daOle.InsertCommand.Parameters.Add("@nombre", OleDbType.VarChar, 50, "Nombre");
            //_daOle.InsertCommand.Parameters.Add("@edad", OleDbType.Integer, 0, "Edad");

            //// Paso el comando de modificacion al 'UpDateCommand'
            //_daOle.UpdateCommand = _cmdUpdateOle;

            //// creo los parametros que va a utilizar
            //_daOle.UpdateCommand.Parameters.Add("@dni", OleDbType.BigInt, 0, "Dni");
            //_daOle.UpdateCommand.Parameters.Add("@apellido", OleDbType.VarChar, 50, "Apellido");
            //_daOle.UpdateCommand.Parameters.Add("@nombre", OleDbType.VarChar, 50, "Nombre");
            //_daOle.UpdateCommand.Parameters.Add("@edad", OleDbType.Integer, 0, "Edad");

            //// Paso el comando de eliminacion al 'DeleteCommand'
            //_daOle.DeleteCommand = _cmdDeleteOle;

            //// creo los parametros que va a utilizar
            //_daOle.DeleteCommand.Parameters.Add("@dni", OleDbType.BigInt, 0, "Dni");

        }

        #endregion

        #region Constructores

        public Clientes(long dni, string nom, string ape, int edad, int nroCuenta):base(dni, nom, ape, edad)
        {
            _nroCuenta = nroCuenta;
            // Saldo por defecto
            _saldo = 1000;
        }

        #endregion

        #region Propriedades

        public double Saldo
        {
            get { return _saldo; }
            set { _saldo = value; }
        }

        public int NroCuenta
        {
            get { return _nroCuenta; }
        }

        #endregion

        
#region Metodos

        public static DataSet TraerDatos()
        {

            // Llamo al Procedimiento que configura al DataAdapter
            ConfigurarDataAdapter();

            // Para Sql
            try
            {
                // Cargo el DataSet utilizando el DataAdapter
                _daCliente.Fill(_ds, "Clientes");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            // Para OleDb
            //try
            //{
            //    // Cargo el DataSet utilizando el DataAdapter
            //    _daOle.Fill(_ds)

            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}

            return _ds;

        }

        public void AgregarCliente()
        {

            // Para Sql
            try
            {
                // Actualizo la Base de Datos mediante
                // el metodo Update del DataAdapter
                _daCliente.Update(_ds.Tables["Clientes"]);

                MessageBox.Show("Cliente Agregado");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            // OleDb
            // try
            // {
            //     _daOle.Update(_ds);
            //    MessageBox.Show("Cliente Agregado");

            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
        }

        public static void ModificarCliente()
        {

            // Para Sql
            try
            {
                // Actualizo la Base de Datos mediante
                // el metodo Update del DataAdapter
                _daCliente.Update(_ds.Tables[0]);

                MessageBox.Show("Cliente Modificado");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            //Para oledb
            // try
            // {
            //     _daOle.Update(_ds);
            // }
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}


        }

        public static void EliminarCliente()
        {

            // Para Sql
            try
            {
                // Actualizo la Base de Datos mediante
                // el metodo Update del DataAdapter
                _daCliente.Update(_ds.Tables["Clientes"]);

                MessageBox.Show("Cliente Eliminado");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            ////Para Oledb
            //try
            //{
            //    _daOle.Update(_ds)
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}


        }

        #endregion

    }
}